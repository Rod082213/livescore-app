// src/lib/api.ts (Complete and Updated)

import { cache } from 'react';
import { Match, LeagueGroup, Standing, Player, ApiFixture, ApiOdd, ApiStanding, ApiPlayer, ApiLeague, MatchDetails } from "@/data/mockData";
import { format } from 'date-fns';

const API_URL = 'https://v3.football.api-sports.io';
const API_KEY = process.env.NEXT_PUBLIC_FOOTBALL_API_KEY;

const serverOptions: RequestInit = {
  method: 'GET',
  headers: { 'x-apisports-key': API_KEY as string },
  next: { revalidate: 3600 } // Cache API results for 1 hour
};

// --- TYPE DEFINITION FOR THE NEW FUNCTION ---
// Defines the shape of the team object we want to return
type Team = {
  id: number;
  name: string;
  logo: string;
};


// --- MAPPING FUNCTIONS (Your existing code is untouched) ---

function mapStatus(status: any): { status: Match['status'], time?: string } {
    if (['FT', 'AET', 'PEN'].includes(status.short)) return { status: 'FT', time: 'FT' };
    if (status.short === 'HT') return { status: 'HT', time: 'HT' };
    if (status.short === 'NS') return { status: 'UPCOMING', time: 'Upcoming' };
    if (status.elapsed) return { status: 'LIVE', time: `${status.elapsed}'` };
    return { status: 'UPCOMING', time: status.short };
}

export function mapApiFixtureToMatch(apiFixture: any): Match | null {
    if (!apiFixture || !apiFixture.fixture || !apiFixture.league) return null;
    let { status, time } = mapStatus(apiFixture.fixture.status);
    if (status === 'UPCOMING' && apiFixture.fixture.date) {
        time = format(new Date(apiFixture.fixture.date), 'HH:mm');
    }
    const match: Match = {
        id: apiFixture.fixture.id, time: time || '', status,
        homeTeam: { name: apiFixture.teams.home.name, logo: apiFixture.teams.home.logo },
        awayTeam: { name: apiFixture.teams.away.name, logo: apiFixture.teams.away.logo },
        score: `${apiFixture.goals.home ?? '-'} - ${apiFixture.goals.away ?? '-'}`,
        league: { id: apiFixture.league.id, name: apiFixture.league.name, logo: apiFixture.league.logo, country: apiFixture.league.country, flag: apiFixture.league.flag }
    };
    return match;
}

export function groupMatchesByLeague(matches: Match[]): LeagueGroup[] {
  if (!matches || matches.length === 0) return [];
  const grouped = matches.reduce((acc, match) => {
    const leagueName = match.league.name;
    if (!acc[leagueName]) {
      acc[leagueName] = { leagueName: leagueName, leagueLogo: match.league.logo || '', countryName: match.league.country || 'World', countryFlag: match.league.flag || '', matches: [] };
    }
    acc[leagueName].matches.push(match);
    return acc;
  }, {} as Record<string, LeagueGroup>);
  return Object.values(grouped);
}

function mapApiStandingToStanding(apiStanding: ApiStanding): Standing {
    return {
        rank: apiStanding.rank, team: { id: apiStanding.team.id, name: apiStanding.team.name, logo: apiStanding.team.logo },
        played: apiStanding.all.played, win: apiStanding.all.win, draw: apiStanding.all.draw, loss: apiStanding.all.loss,
        diff: apiStanding.goalsDiff.toString(), points: apiStanding.points,
        form: apiStanding.form?.split('').slice(0, 5) as ('W' | 'D' | 'L')[] || []
    };
}


// --- CACHED DATA FETCHING FUNCTIONS (Your existing code is untouched) ---

export const fetchDashboardData = cache(async (): Promise<LeagueGroup[]> => {
    if (!API_KEY) return [];
    try {
        const todayStr = new Date().toISOString().split('T')[0];
        const [liveResponse, todayResponse] = await Promise.all([
            fetch(`${API_URL}/fixtures?live=all`, serverOptions),
            fetch(`${API_URL}/fixtures?date=${todayStr}`, serverOptions)
        ]);
        if (!liveResponse.ok || !todayResponse.ok) return [];
        const liveData = await liveResponse.json();
        const todayData = await todayResponse.json();
        const allFixtures: ApiFixture[] = Array.from(new Map([...(liveData.response || []), ...(todayData.response || [])].map(f => [f.fixture.id, f])).values());
        const matches = allFixtures.map(mapApiFixtureToMatch).filter(Boolean) as Match[];
        matches.sort((a, b) => { const order = { 'LIVE': 1, 'HT': 2, 'UPCOMING': 3, 'FT': 4 }; return order[a.status] - order[b.status]; });
        return groupMatchesByLeague(matches);
    } catch (error) { return []; }
});

export const fetchTopLeagues = cache(async (): Promise<ApiLeague[]> => {
    if (!API_KEY) return [];
    try {
        const leagueIds = [39, 140, 135, 78, 61, 2, 3, 88, 94, 253];
        const responses = await Promise.all(leagueIds.map(id => fetch(`${API_URL}/leagues?id=${id}`, serverOptions)));
        const results = await Promise.all(responses.map(res => res.json()));
        return results.map(result => result.response[0]?.league).filter(Boolean);
    } catch (error) { return []; }
});

export const fetchStandings = cache(async (leagueId: string, season: string = "2024"): Promise<Standing[]> => {
    if (!API_KEY) return [];
    try {
        const response = await fetch(`${API_URL}/standings?league=${leagueId}&season=${season}`, serverOptions);
        if (!response.ok) return [];
        const data = await response.json();
        const standingsData = data.response[0]?.league?.standings[0];
        return standingsData ? standingsData.map(mapApiStandingToStanding) : [];
    } catch (error) { return []; }
});

// ==================================================================
// === THIS IS THE NEW FUNCTION YOU NEED FOR THE TOP-TEAMS PAGE ===
// ==================================================================
export const fetchAllTeamsInLeague = cache(async (leagueId: string, season: string = "2024"): Promise<Team[]> => {
  // If no leagueId is provided, we can't fetch anything.
  if (!API_KEY || !leagueId) {
    return [];
  }
  
  try {
    const url = `${API_URL}/teams?league=${leagueId}&season=${season}`;
    const response = await fetch(url, serverOptions);

    if (!response.ok) {
      console.error(`API Error: Failed to fetch teams for league ${leagueId}`);
      return [];
    }

    const data = await response.json();
    
    // The API response is an array of objects, each containing a 'team' property.
    // We map over this array to extract just the team data.
    const teams: Team[] = (data.response || []).map((item: any) => ({
      id: item.team.id,
      name: item.team.name,
      logo: item.team.logo,
    }));

    return teams;
    
  } catch (error) {
    console.error("Error in fetchAllTeamsInLeague:", error);
    return [];
  }
});
// ==================================================================

export const fetchAllTeamsFromAllLeagues = cache(async (): Promise<{ leagueName: string, teams: { id: number, name: string, logo: string }[] }[]> => {
    if (!API_KEY) return [];
    try {
        const leagueIds = [39, 140, 135, 78, 61, 2, 3, 88, 94, 253];
        const leagueDetailsPromises = leagueIds.map(id => fetch(`${API_URL}/leagues?id=${id}`, serverOptions).then(res => res.ok ? res.json() : null));
        const leagueDetailsResults = await Promise.all(leagueDetailsPromises);
        const leaguesMap = new Map(
            leagueDetailsResults
                .filter(result => result && result.response && result.response[0] && result.response[0].league)
                .map(result => [result.response[0].league.id, result.response[0].league.name])
        );
        const teamsPromises = leagueIds.map(id => fetch(`${API_URL}/teams?league=${id}&season=2024`, serverOptions).then(res => res.ok ? res.json() : null));
        const teamsResults = await Promise.all(teamsPromises);
        return teamsResults.filter(result => result && result.response && result.response.length > 0).map(result => {
            const leagueId = result.parameters.league;
            const leagueName = leaguesMap.get(parseInt(leagueId)) || 'Unknown League';
            const teams = result.response.map((item: any) => ({ id: item.team.id, name: item.team.name, logo: item.team.logo }));
            return { leagueName, teams };
        });
    } catch (error) { return []; }
});

export const fetchTeamOfTheWeek = cache(async (leagueId: string = "39", season: string = "2024"): Promise<Player[]> => {
    if (!API_KEY) return [];
    try {
        const url = `${API_URL}/players/topscorers?season=${season}&league=${leagueId}`;
        const response = await fetch(url, serverOptions);
        if (!response.ok) return [];
        const data = await response.json();
        const topPlayers: ApiPlayer[] = data.response?.slice(0, 5) || [];
        return topPlayers.map(p => ({
            name: p.player.name,
            rating: parseFloat(p.statistics[0].games.rating || '0').toFixed(1),
            logo: p.statistics[0].team.logo,
        }));
    } catch (error) { return []; }
});

export const fetchAllTopPlayers = cache(async (leagueId: string = "39", season: string = "2024"): Promise<Player[]> => {
    if (!API_KEY) return [];
    try {
        const url = `${API_URL}/players/topscorers?season=${season}&league=${leagueId}`;
        const response = await fetch(url, serverOptions);
        if (!response.ok) return [];
        const data = await response.json();
        const topPlayers: ApiPlayer[] = data.response || [];
        return topPlayers.map(p => ({
            name: p.player.name,
            rating: parseFloat(p.statistics[0].games.rating || '0').toFixed(1),
            logo: p.statistics[0].team.logo,
            id: p.player.id,
            teamName: p.statistics[0].team.name
        }));
    } catch (error) {
        console.error("Error in fetchAllTopPlayers:", error);
        return [];
    }
});

export const fetchTeamInfo = cache(async (teamId: string) => {
    if (!API_KEY) return null;
    try {
        const res = await fetch(`${API_URL}/teams?id=${teamId}`, serverOptions);
        if (!res.ok) return null;
        const data = await res.json();
        return data.response[0] || null;
    } catch (error) { return null; }
});

export const fetchTeamFixtures = cache(async (teamId: string, season: string = "2024") => {
    if (!API_KEY) return [];
    try {
        const res = await fetch(`${API_URL}/fixtures?team=${teamId}&season=${season}`, serverOptions);
        if (!res.ok) return [];
        const data = await res.json();
        return (data.response || []).map(mapApiFixtureToMatch).filter(Boolean) as Match[];
    } catch (error) { return []; }
});

export const fetchTeamSquad = cache(async (teamId: string) => {
    if (!API_KEY) return [];
    try {
        const res = await fetch(`${API_URL}/players/squads?team=${teamId}`, serverOptions);
        if (!res.ok) return [];
        const data = await res.json();
        return data.response[0]?.players || [];
    } catch (error) { return []; }
});

export const fetchMatchDetailsById = cache(async (id: string): Promise<MatchDetails | null> => {
    if (!API_KEY) { return null; }
    try {
        const fixtureRes = await fetch(`${API_URL}/fixtures?id=${id}`, serverOptions);
        if (!fixtureRes.ok) return null;
        const fixtureData = await fixtureRes.json();
        const apiFixture: ApiFixture = fixtureData.response?.[0];
        if (!apiFixture) return null;
        const match: MatchDetails = mapApiFixtureToMatch(apiFixture) as MatchDetails;
        const [eventsRes, statsRes] = await Promise.all([
            fetch(`${API_URL}/fixtures/events?fixture=${id}`, serverOptions),
            fetch(`${API_URL}/fixtures/statistics?fixture=${id}`, serverOptions),
        ]);
        if (eventsRes.ok) match.events = (await eventsRes.json()).response;
        if (statsRes.ok) {
            const statsData = await statsRes.json();
            if (statsData.response && statsData.response.length > 0) {
                const homeStatsRaw = statsData.response.find((s: any) => s.team.id === apiFixture.teams.home.id)?.statistics || [];
                const awayStatsRaw = statsData.response.find((s: any) => s.team.id === apiFixture.teams.away.id)?.statistics || [];
                const processedStats: Record<string, { home: any; away: any; }> = {};
                const allStatTypes = new Set([...homeStatsRaw.map((s: any) => s.type), ...awayStatsRaw.map((s: any) => s.type)]);
                allStatTypes.forEach(type => {
                    const homeValue = homeStatsRaw.find((s: any) => s.type === type)?.value ?? 0;
                    const awayValue = awayStatsRaw.find((s: any) => s.type === type)?.value ?? 0;
                    processedStats[type] = { home: homeValue, away: awayValue };
                });
                match.statistics = processedStats;
            }
        }
        return match;
    } catch (error) { return null; }
});