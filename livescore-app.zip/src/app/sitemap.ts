// src/app/sitemap.ts

import { MetadataRoute } from 'next';
import { fetchAllTeamsFromAllLeagues } from '@/lib/api'; // To get all teams
import { fetchNewsList } from '@/lib/news-api'; // To get all news articles
import { createSlug } from '@/lib/utils'; // To create slugs for teams

// This tells Next.js to generate this sitemap at build time.
// It's a best practice for performance and reliability.
export const dynamic = 'force-static';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // Make sure to set this in your .env.local file
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

  // 1. Static pages that are always present
  const staticUrls: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1.0,
    },
    {
      url: `${baseUrl}/news`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/teams-list`,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 0.8,
    },
  ];

  // 2. Dynamic pages for each news article
  // We add a .catch to prevent the entire sitemap build from failing if the API is down.
  const allNews = await fetchNewsList().catch(() => []);
  const newsUrls: MetadataRoute.Sitemap = allNews.map(article => ({
    url: `${baseUrl}/news/${article.slug}`,
    lastModified: new Date(article.publishedAt || Date.now()),
    changeFrequency: 'monthly',
    priority: 0.7,
  }));

  // 3. Dynamic pages for each team
  const allLeagues = await fetchAllTeamsFromAllLeagues().catch(() => []);
  const allTeams = allLeagues.flatMap(league => league.teams); // Flatten the array
  const teamUrls: MetadataRoute.Sitemap = allTeams.map(team => ({
    url: `${baseUrl}/team/${createSlug(team.name)}`,
    lastModified: new Date(), // Teams don't have an `updatedAt`, so we use the current date
    changeFrequency: 'monthly',
    priority: 0.6,
  }));

  // Combine all URLs into a single array and return
  return [
    ...staticUrls,
    ...newsUrls,
    ...teamUrls,
  ];
}