// src/app/team/[slug]/page.tsx

import { notFound } from 'next/navigation';
import { Metadata } from 'next'; // Make sure Metadata is imported
import { 
  fetchTeamInfo, 
  fetchTeamFixtures, 
  fetchTeamSquad, 
  fetchStandings, 
  fetchAllTeamsFromAllLeagues 
} from '@/lib/api';
import { createSlug } from '@/lib/utils';

// Component Imports
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SportsNav from '@/components/SportsNav';
import TeamHeader from '@/components/team/TeamHeader';
import VenueInformation from '@/components/team/VenueInformation';
import MatchSchedule from '@/components/team/MatchSchedule';
import LeagueStandings from '@/components/team/LeagueStandings';
import SquadList from '@/components/team/SquadList';

type Props = { params: { slug: string } };

// --- THIS IS THE NEW, DYNAMIC METADATA FUNCTION ---
// It replaces the incorrect static 'metadata' object.
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const slug = params.slug;

  // Find the team to get its name, ID, and logo.
  // This fetch is automatically de-duplicated by Next.js and reused by the page component below.
  const allLeagues = await fetchAllTeamsFromAllLeagues();
  const allTeams = allLeagues.flatMap(league => league.teams);
  const team = allTeams.find(t => createSlug(t.name) === slug);

  // Handle case where the team is not found

  
  // Construct dynamic metadata that is perfectly optimized for SEO.
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const canonicalUrl = `${siteUrl}/team/${slug}`;
  const imageUrl = team.logo || `${siteUrl}/default-social-card.png`;

  const dynamicTitle = `${team.name}: Live Scores, Fixtures & Standings`;
  const dynamicDescription = `Get the latest live scores, match schedule, league standings, and full squad list for ${team.name}. Follow all the action on TodayLiveScores.`;

  return {
    // Title is under 60 characters and will be used by the layout's template.
    title: dynamicTitle,

    // Description is under 160 characters, ensuring it stays "green" in SEO tools.
    description: dynamicDescription,

    keywords: [team.name, `${team.name} scores`, `${team.name} fixtures`, 'live scores', 'football', 'standings', 'squad list'],
    
    alternates: {
      canonical: canonicalUrl,
    },
    
    openGraph: {
      title: `${dynamicTitle} | TodayLiveScores`,
      description: dynamicDescription,
      url: canonicalUrl,
      siteName: 'TodayLiveScores',
      images: [{
        url: imageUrl,
        width: 200, // Logos are often square, so specific dimensions are good
        height: 200,
        alt: `${team.name} logo`,
      }],
      locale: 'en_US',
      type: 'website',
    },

    twitter: {
      card: 'summary', // 'summary' is better for square logo images
      title: `${dynamicTitle} | TodayLiveScores`,
      description: dynamicDescription,
      images: [imageUrl],
    },
  };
}


// --- YOUR EXISTING PAGE COMPONENT (UNCHANGED) ---
export default async function TeamDetailPage({ params }: { params: { slug: string } }) {
  const slug = params.slug;

  const allLeagues = await fetchAllTeamsFromAllLeagues();
  const allTeams = allLeagues.flatMap(league => league.teams);
  const teamFromList = allTeams.find(t => createSlug(t.name) === slug);

  if (!teamFromList) {
    notFound();
  }

  const teamId = teamFromList.id.toString();

  const [teamInfo, fixtures, squad] = await Promise.all([
    fetchTeamInfo(teamId),
    fetchTeamFixtures(teamId),
    fetchTeamSquad(teamId)
  ]);

  if (!teamInfo) {
    notFound();
  }
  
  const leagueId = (fixtures && fixtures.length > 0 && fixtures[0].league)
    ? fixtures[0].league.id.toString() 
    : null;

  const standings = leagueId ? await fetchStandings(leagueId) : [];

  return (
    <div className="bg-[#1d222d] text-gray-200 min-h-screen">
      <Header />
      <SportsNav />
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col gap-6">

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <TeamHeader team={teamInfo.team} />
            </div>
            <div>
              <VenueInformation venue={teamInfo.venue} />
            </div>
          </div>

          <MatchSchedule fixtures={fixtures} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <LeagueStandings standings={standings} teamId={teamFromList.id} />
            </div>
            <div className="lg:col-span-2">
              <SquadList squad={squad} />
            </div>
          </div>
          
        </div>
      </div>
      <Footer />
    </div>
  );
}

// --- YOUR EXISTING generateStaticParams FUNCTION (UNCHANGED) ---
export async function generateStaticParams() {
  const allLeagues = await fetchAllTeamsFromAllLeagues();
  const allTeams = allLeagues.flatMap(league => league.teams);
 
  return allTeams.map((team) => ({
    slug: createSlug(team.name),
  }));
}