// src/app/teams-list/page.tsx

import Link from 'next/link';
import Image from 'next/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SportsNav from '@/components/SportsNav';
import LeftSidebar from '@/components/LeftSidebar';
import TeamSidebar from '@/components/TeamSidebar';
import { Metadata } from 'next';


import { 
  fetchAllTeamsFromAllLeagues,
  fetchTeamOfTheWeek,
} from '@/lib/api';
import { fetchNewsList } from '@/lib/news-api';
import { createSlug } from '@/lib/utils'; // <--- 1. IMPORT THE SLUG FUNCTION

export const metadata: Metadata = {
  // Title is already good, no changes needed here.
  title: 'Browse All Football Teams by League',

  // --- THIS IS THE FIX ---
  // The new description is ~155 characters. It's concise, keyword-rich, and has a clear call to action.
  description: 'Explore a complete directory of football teams from top leagues worldwide. Select any team to view their live scores, upcoming fixtures, and league standings.',

  // Keywords remain useful for some search engines and for context.
  keywords: ['football teams', 'team list', 'team directory', 'all teams', 'premier league', 'la liga', 'serie a', 'bundesliga', 'sports teams', 'football leagues'],

  // Canonical URL is still a best practice.
  alternates: {
    canonical: '/teams-list',
  },

  // Open Graph tags for social sharing, now with the corrected description.
  openGraph: {
    title: 'Browse All Football Teams by League | TLiveScores',
    // --- UPDATED DESCRIPTION ---
    description: 'Explore a complete directory of football teams from top leagues worldwide. Select any team to view their live scores, upcoming fixtures, and league standings.',
    url: '/teams-list',
    siteName: 'TLiveScores',
    images: [
      {
        url: '/social-card-teams.png', // Remember to create this image
        width: 1200,
        height: 630,
        alt: 'A directory of all football teams on TLiveScores',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },

  // Twitter-specific tags with the corrected description.
  twitter: {
    card: 'summary_large_image',
    title: 'Browse All Football Teams by League | TLiveScores',
    // --- UPDATED DESCRIPTION ---
    description: 'Explore a complete directory of football teams from top leagues worldwide. Select any team to view their live scores, upcoming fixtures, and league standings.',
    images: ['/social-card-teams.png'],
  },

  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
    },
  },
};

export default async function AllTeamsListPage() {
  
  const [allLeagues, teamOfTheWeek, allNews] = await Promise.all([
    fetchAllTeamsFromAllLeagues(),
    fetchTeamOfTheWeek(),
    fetchNewsList()
  ]);

  const latestNewsForSidebar = allNews.slice(0, 3);

  return (
    <div className="bg-[#1d222d] text-gray-200 min-h-screen">
      <Header />
      <SportsNav />
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
            
          <aside className="lg:w-72 lg:flex-shrink-0 lg:sticky lg:top-4 lg:self-start">
            <LeftSidebar 
              teamOfTheWeek={teamOfTheWeek} 
              latestNews={latestNewsForSidebar}
            />
          </aside>
            
          <main className="w-full lg:flex-1">
            <h1 className="text-3xl font-bold text-white mb-8">All Teams By League</h1>
            <div className="space-y-10">
              {allLeagues.map((league) => (
                <div key={league.leagueName}>
                  <h2 className="text-2xl font-semibold text-white mb-4 border-b-2 border-gray-700 pb-2">
                    {league.leagueName}
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {league.teams.map((team) => (
                      <Link 
                        key={team.id}
                        // 2. --- THIS IS THE CHANGE ---
                        // Before: href={`/team/${team.id}`}
                        // After: Use the createSlug function on the team's name
                        href={`/team/${createSlug(team.name)}`}
                        className="group bg-[#2b3341] p-4 rounded-lg flex flex-col items-center justify-center text-center hover:bg-[#3e4859] transition-colors"
                      >
                        <Image
                          src={team.logo}
                          alt={team.name}
                          width={64}
                          height={64}
                          className="h-16 w-16 object-contain mb-3"
                        />
                        <h3 className="text-white font-semibold text-sm group-hover:underline">
                          {team.name}
                        </h3>
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </main>
          
          <aside className="lg:w-72 lg:flex-shrink-0 lg:sticky lg:top-4 lg:self-start">
             <TeamSidebar />
          </aside>

        </div>
      </div>
      <Footer />
    </div>
  );
}